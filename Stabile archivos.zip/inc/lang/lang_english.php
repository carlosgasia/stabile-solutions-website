<?php
// <!-- home page -->

        // <!-- bar nav -->

        $nosotros = 'We';
        $servicios = 'Services';
        $clientes = 'Clients';
        $portafolio = 'Portfolio';
        $contacto = 'Contact';
        $idiomas = 'Language';


    // <!-- Home title -->
        $tituloHome = 'Stable solutions for a changing world';

 $quienesSomos = 'About us';
 $quienesSomos_contenido = 'We are a curazaleño software developer, whose purpose is to create stable solutions to our customers that allow them to increase their performance through the generation and use of information, technology and knowledge. <br> <br>Since 2020, we have provided different companies and administrative organizations with solutions that last in the medium and long term and are comprehensive and effective.';

$misionTitulo = 'Mission';
$misionContenido = 'To provide stable technological solutions that are a solid foundation for small and medium-sized companies that will last over the years, in order to increase the productivity, competitiveness and operability of our clients.';

$visionTitulo = 'Vision';
$visionContenido = 'Establish in Latin America as one of the most solid companies in the software development market by the year 2030. To be a leading company in the development of state-of-the-art technologies, always adapting to the changing market conditions and to the demands and needs of our customers.';

$nuestrosServicios = 'Our services';

$servicioA = 'Business';
$servicioAContenido = 'Requirements Engineering<br>
Business Process Modeling<br>
Project Planning and Control<br>
Business Intelligence';

$servicioB = 'Development';

$servicioBContenido = 'Software Design<br>
Software Development<br>
Software Configuration<br>
Quality Assurance';

$servicioC = 'Database';

$servicioCContenido = 'Integral Database Design<br>
Database Administration<br>
Data Mining';

$servicioD = 'Design';

$servicioDContenido = 'Requirements Engineering<br>
Business Process Modeling<br>
Project Planning and Control<br>
Business Intelligence';

$hemosTrabajadoCon = 'We have worked with: ';

$portafolio = 'Portfolio';

$proyectoA = 'Proyect X';
$proyectoAContenido = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
placerat elementum dui et volutpat. Aliquam consequat placerat tortor vel hendrerit. Morbi mollis venenatis
sem eget elementum.';

$proyectoB = 'Curacao Help';
$proyectoBContenido = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
placerat elementum dui et volutpat. Aliquam consequat placerat tortor vel hendrerit. Morbi mollis venenatis
sem eget elementum.';

$proyectoC = 'Responsible Help';

$proyectoCContenido = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
placerat elementum dui et volutpat. Aliquam consequat placerat tortor vel hendrerit. Morbi mollis venenatis
sem eget elementum.';

$verAqui = 'See here';

$contactanos = 'Contact us!';

$contactanosContenido = 'To contact us, please fill out the form.';


// Formulario de contactanos

$mensajeFormulario = 'Your menssage';
$nombreFormulario = 'Name';
$nombreFormularioPlaceholder = 'Enter your name';

$correoFormulario = 'E-mail';
$correoFormularioPlaceholder = 'Enter your E-mail';
$asuntoFormulario = 'Mail subject';
$asuntoFormularioPlaceholder = 'Enter the mail subject';
$MensajeFormulario = 'Menssage';
$mensajeFormularioPlaceholder = 'Enter your menssage';
$btnEnviar = 'Send';
$resetBTN = 'Reset';


$copyright = ' All rights reserved.';

$thanksforsend = 'Thanks!';

$successfulEmail = 'The information has been sent correctly.';

$goBack = 'Go back to home';




















?>