<?php
// <!-- home page -->

        // <!-- bar nav -->

        $nosotros = 'Nosotros';
        $servicios = 'Servicios';
        $clientes = 'Clientes';
        $portafolio = 'Portafolio';
        $contacto = 'Contacto';
        $idiomas = 'Idiomas';


    // <!-- Home title -->
        $tituloHome = 'Soluciones estables para un mundo cambiante';

 $quienesSomos = '¿Qui&eacute;nes somos?';
 $quienesSomos_contenido = 'Somos una desarrolladora de Software curazaleño, cuyo propósito es crear soluciones estables
        a nuestros
        clientes que les permita incrementar su rendimiento mediante la generación y el aprovechamiento de la
        información, tecnología y el conocimiento. <br> <br>Desde 2020 se ha proporcionado a diferentes empresas y organizaciones administrativas
        soluciones que perduren
        a mediano
        y largo plazo siendo estas mismas integrales y efectivas.';

$misionTitulo = 'Misión';
$misionContenido = 'Garantizar soluciones tecnológicas estables que sean cimientos sólidos para pequeñas y
medianas empresas que
perduren a
lo largo de los años, con la finalidad de incrementar la productividad, la competitividad y la operatividad de
nuestros
clientes.';

$visionTitulo = 'Visión';
$visionContenido = 'Establecerse en Latinoamérica como una de las empresas mas solidas en el mercado del
desarrollo del software
para el año
2030. Ser una empresa líder en desarrollo de tecnologías de última generación adaptándonos siempre a las
cambiantes
condiciones del mercado y a las demandas y necesidades de nuestros clientes.';

$nuestrosServicios = 'Nuestros servicios';

$servicioA = 'Negocios';
$servicioAContenido = 'Ingeniería de Requerimiento<br>
Modelado de Procesos de Negocio<br>
Planificación y Control de Proyecto<br>
Inteligencia de Negocio';

$servicioB = 'Desarrollo';

$servicioBContenido = 'Diseño de Software<br>
Desarrollo de Software<br>
Configuración de Software<br>
Aseguramiento de Calidad';

$servicioC = 'Base de Datos';

$servicioCContenido = 'Diseño Integral de Base de Datos<br>
Administración de Base de Datos<br>
Minería de Datos';

$servicioD = 'Diseño';

$servicioDContenido = 'Ingeniería de Requerimiento<br>
Modelado de Procesos de Negocio<br>
Planificación y Control de Proyecto<br>
Inteligencia de Negocio';

$hemosTrabajadoCon = 'Hemos trabajado con: ';

$portafolio = 'Portafolio';

$proyectoA = 'Proyecto X';
$proyectoAContenido = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
placerat elementum dui et volutpat. Aliquam consequat placerat tortor vel hendrerit. Morbi mollis venenatis
sem eget elementum.';

$proyectoB = 'Proyecto Y';
$proyectoBContenido = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
placerat elementum dui et volutpat. Aliquam consequat placerat tortor vel hendrerit. Morbi mollis venenatis
sem eget elementum.';

$proyectoC = 'Responsible Help';

$proyectoCContenido = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
placerat elementum dui et volutpat. Aliquam consequat placerat tortor vel hendrerit. Morbi mollis venenatis
sem eget elementum.';

$verAqui = 'Ver aquí';

$contactanos = 'Contactános';

$contactanosContenido = 'Para contactarnos, rellena el siguiente formulario.';


// Formulario de contactanos

$mensajeFormulario = 'Tu mensaje';
$nombreFormulario = 'Nombre';
$nombreFormularioPlaceholder = 'Ingrese su nombre';

$correoFormulario = 'E-mail';
$correoFormularioPlaceholder = 'Ingrese su E-mail';
$asuntoFormulario = 'Asunto';
$asuntoFormularioPlaceholder = 'Ingrese su asunto';
$MensajeFormulario = 'Mensaje';
$mensajeFormularioPlaceholder = 'Ingrese su mensaje';
$btnEnviar = 'Enviar';

$copyright = ' Todos los derechos reservados.';

$thanksforsend = 'Gracias!';

$successfulEmail = 'La información se ha enviado correctamente.';

$goBack = 'Volver';


















?>