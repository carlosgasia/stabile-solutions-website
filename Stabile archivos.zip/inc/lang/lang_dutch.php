<?php
// <!-- home page -->

        // <!-- bar nav -->

        $nosotros = 'Wij';
        $servicios = 'Diensten';
        $clientes = 'Klanten';
        $portafolio = 'Portefeuille';
        $contacto = 'Contacten';
        $idiomas = 'Talen';


    // <!-- Home title -->
        $tituloHome = 'Stabiele oplossingen voor een veranderende wereld';

 $quienesSomos = 'Wie zijn wij?';
 $quienesSomos_contenido = 'Wij zijn een curazaleño software ontwikkelingsbedrijf, wiens doel het is om stabiele oplossingen te creëren
 naar onze
 klanten die hen in staat stellen hun prestaties te verbeteren door het genereren en gebruiken van informatie, technologie en kennis.
 informatie, technologie en kennis. <br> <br>Sinds 2020 voorzien wij verschillende bedrijven en administratieve organisaties van
 oplossingen die lang zullen duren
 in het medium
 en langetermijnoplossingen die alomvattend en doeltreffend zijn.';

$misionTitulo = 'Missie';
$misionContenido = 'Zorgen voor stabiele technologieoplossingen die een solide basis vormen voor kleine en middelgrote ondernemingen die
middelgrote ondernemingen die
dat zal blijven duren
de productiviteit, het concurrentievermogen en de operabiliteit van onze kleine en middelgrote ondernemingen te verhogen.
onze
onze klanten.';

$visionTitulo = 'Vision';
$visionContenido = 'Zich in Latijns-Amerika te vestigen als een van de sterkste bedrijven op de markt van de software-ontwikkeling.
softwareontwikkeling
per jaar
2030. Een toonaangevend bedrijf zijn in de ontwikkeling van ultramoderne technologieën, dat zich steeds aanpast aan de steeds veranderende
veranderen
marktomstandigheden en aan de eisen en behoeften van onze klanten.';

$nuestrosServicios = 'Onze diensten';

$servicioA = 'BUSINESS';
$servicioAContenido = 'Eisen-engineering<br>
Modelleren van bedrijfsprocessen<br>
Projectplanning en -beheersing<br>
Business Intelligence';

$servicioB = 'ONTWIKKELING';

$servicioBContenido = 'Software Ontwerp<br>
Software Ontwikkeling<br>
Software Configuratie<br>
Kwaliteitsborging';

$servicioC = 'DATABASE';

$servicioCContenido = 'Geïntegreerd databankontwerp<br>
Databasebeheer<br>
Datamining';

$servicioD = 'ONTWERP';

$servicioDContenido = 'Eisen-engineering<br>
Modelleren van bedrijfsprocessen<br>
Projectplanning en -beheersing<br>
Business Intelligence';


$hemosTrabajadoCon = 'We hebben gewerkt met:';

$portafolio = 'Portefeuille';

$proyectoA = 'Proyect X';
$proyectoAContenido = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
placerat elementum dui et volutpat. Aliquam consequat placerat tortor vel hendrerit. Morbi mollis venenatis
sem eget elementum.';

$proyectoB = 'Curacao Help';
$proyectoBContenido = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
placerat elementum dui et volutpat. Aliquam consequat placerat tortor vel hendrerit. Morbi mollis venenatis
sem eget elementum.';

$proyectoC = 'Responsible Help';

$proyectoCContenido = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
placerat elementum dui et volutpat. Aliquam consequat placerat tortor vel hendrerit. Morbi mollis venenatis
sem eget elementum.';

$verAqui = 'Zie hier';

$contactanos = 'Neem contact met ons op';

$contactanosContenido = 'Om ons te contacteren, gelieve onderstaand formulier in te vullen.';


// Formulario de contactanos

$mensajeFormulario = 'Uw bericht';
$nombreFormulario = 'Naam';
$nombreFormularioPlaceholder = 'Vul uw naam in';

$correoFormulario = 'E-mail';
$correoFormularioPlaceholder = 'Ondernemingen per e-mail';
$asuntoFormulario = 'Onderwerp';
$asuntoFormularioPlaceholder = 'Voer uw onderwerp in';
$MensajeFormulario = 'Bericht';
$mensajeFormularioPlaceholder = 'bericht';
$btnEnviar = 'Stuur';
$resetBTN = 'Reset';

$copyright = 'Alle rechten voorbehouden.';

$thanksforsend = 'Dank je!';

$successfulEmail = 'De informatie is correct verzonden.';

$goBack = 'Terug naar';


















?>