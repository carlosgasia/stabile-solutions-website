
<!-- footer -->
<footer class="site-footer seccion">
    <div class="container contenedor-footer clearfix">
        
        <p class="copyright">Stabile Solutions &#169; <?php echo date('Y') ?> <?php echo $copyright ?></p>
        <a href="mailto:carlos.gasia@outlook.com"><p class="author">A C.A.G.L's design</p></a>
    </div>
</footer>
<div id="preloader">
    <div id="loader">
    </div>
  </div>
  <script src="js/index_dom.js" type="module"></script>

</body>
</html>